﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('RegisterController', RegisterController);

    RegisterController.$inject = ['UserService', '$location'];
    function RegisterController(UserService, $location) {

        var vm = this;
        vm.registerUser = registerUser;

        function registerUser() {
            if (vm.form.$invalid || vm.dataLoading) {return;}
            vm.dataLoading = true;
            UserService.Create(vm.user)
                .then(function (response) {
                    if (response.success) {
                        $location.path('/login');
                    } else {
                        vm.dataLoading = false;
                    }
                }, function (error) {
                    alert("An error has ocurred! Maybe you have alerady a user with the same username?")
                });
        }
    }

})();
