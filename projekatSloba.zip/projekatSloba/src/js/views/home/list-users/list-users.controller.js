(function () {
    'use strict';

    angular
        .module('app')
        .controller('ListUsersController', ListUsersController);

    ListUsersController.$inject = ['$rootScope', 'UserService', '$uibModal'];
    function ListUsersController($rootScope, UserService, $uibModal) {
        var vm = this;
        vm.listOfUsers = [];
        vm.deleteUser = deleteUser;
        vm.editUser = editUser;
        vm.isCurrentUser = isCurrentUser;

        getUsers();

        function isCurrentUser(user) {
            if (!$rootScope.globals.currentUser) {
                return false
            }

            return user.username == $rootScope.globals.currentUser.username;
        }

        function getUsers() {
            UserService.GetAll().then(function (response) {
                vm.listOfUsers = response;
            }, function () {
                console.log("Error")
            })
        }

        function editUser(user) {
            var modalInstance = $uibModal.open({
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                templateUrl: 'src/js/views/home/list-users/templates/edit-modal.html',
                controller: ['$uibModalInstance', 'user',
                    function ($uibModalInstance, user) {
                    var vm = this;
                    vm.user = user;

                    vm.ok = function () {
                        $uibModalInstance.close({
                            user: vm.user
                        });
                    };

                    vm.close = function () {
                        $uibModalInstance.close(null);
                    }
                }],
                controllerAs: "vm",
                resolve: {
                    user: Object.assign({}, user)
                }
            });

            modalInstance.result.then(function (user) {
                if (user) {
                    UserService.Update(user.user).then(function (res) {
                        if (res.username === $rootScope.globals.currentUser.username) {
                            AuthenticationService.SetCredentials(res.username, res.password, res.isAdmin);
                        }
                        getUsers();
                    });
                }

            }, function () {

            });
        }

        function deleteUser(user) {
            var modalInstance = $uibModal.open({
                ariaLabelledBy: 'modal-title',
                ariaDescribedBy: 'modal-body',
                templateUrl: 'src/js/views/home/list-users/templates/delete-modal.html',
                controller: ['$uibModalInstance', 'id', function ($uibModalInstance, id) {
                    var vm = this;

                    vm.ok = function () {
                        $uibModalInstance.close({
                            userId: id
                        });
                    };

                    vm.close = function () {
                        $uibModalInstance.close(null);
                    }
                }],
                controllerAs: "vm",
                resolve: {
                    id: user.id
                }
            });

            modalInstance.result.then(function (userId) {
                if (userId) {
                    UserService.Delete(userId.userId).then(function (res) {
                        getUsers();
                    });
                }

            }, function () {

            });
        }

    }

})();
