(function () {
    'use strict';

    angular
        .module('app')
        .controller('EditUserController', EditUserController);

    EditUserController.$inject = ['$rootScope', 'UserService', 'AuthenticationService', '$location'];
    function EditUserController($rootScope, UserService, AuthenticationService, $location) {

        var vm = this;
        vm.updateUser = updateUser;

        getUser();

        function updateUser() {
            UserService.Update(vm.user).then(function (result) {
                AuthenticationService.SetCredentials(vm.user.username, vm.user.password, vm.user.isAdmin);
                getUser();
                $location.path('/home');
            });
        }

        function getUser() {
            UserService.GetByUsername($rootScope.globals.currentUser.username).then(function (res) {
                vm.user = res;
            });
        }
    }

})();
