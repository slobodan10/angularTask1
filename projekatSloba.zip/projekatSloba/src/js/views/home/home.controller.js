﻿(function () {
    'use strict';

    angular
        .module('app')
        .controller('HomeController', HomeController);

    HomeController.$inject = ['$location', 'AuthenticationService'];
    function HomeController($location, AuthenticationService) {
        var vm = this;
        vm.logout = logout;
        vm.isActive = isActive;

        vm.user = null;

        function logout() {
            AuthenticationService.ClearCredentials();
            $location.path("/login");

        };

        function isActive(viewLocation) {
            return viewLocation === $location.path();
        };

    }

})();