(function () {
    'use strict';

    angular.module('app')
        .filter('formatDate', function () {
            return function (input) {
                var date = new Date(input);
                var output = date.getDate()  + "-" +
                    (date.getMonth()+1) + "-" + date.getFullYear() + " " +
                    date.getHours() + ":" + (date.getMinutes().length === 1 ? "0" + date.getMinutes(): date.getMinutes());
                return output;
            };
        });

})();