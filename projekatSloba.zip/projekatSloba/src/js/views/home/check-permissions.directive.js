(function () {
    'use strict';

    angular.module('app').directive('checkPermissions', CheckPermissions);
    CheckPermissions.$inject = ['$rootScope'];
    function CheckPermissions($rootScope) {
        return {
            restrict: 'A',
            scope: {
                role: "@"
            },
            link: function (scope, elem) {
                var isAdmin = $rootScope.globals.currentUser.isAdmin;

                switch(scope.role.toLowerCase()) {
                    case 'admin':
                        if (!isAdmin) {
                            elem.remove();
                        }
                        break;
                    case 'user':
                        if (isAdmin) {
                            elem.remove();
                        }
                        break;
                }
            }
        };
    }
})();

