(function () {
    'use strict';

    angular
        .module('app')
        .controller('MyProfileController', MyProfileController);

    MyProfileController.$inject = ['$rootScope', 'UserService', 'AuthenticationService'];
    function MyProfileController($rootScope, UserService, AuthenticationService) {
        var vm = this;
        getUser();

        function getUser() {
            UserService.GetByUsername($rootScope.globals.currentUser.username).then(function(res){
                vm.user = res;
                AuthenticationService.SetCredentials(vm.user.username, vm.user.password, vm.user.isAdmin);
            });
        }
    }

})();
