﻿(function () {
    'use strict';

    angular
        .module('app', ['ngCookies', 'ui.router', 'ui.bootstrap'])
        .provider('providerApp', function () {
            this.$get = function () {
                return {
                    getInitialuser: function () {
                        return {
                            firstName: "admin",
                            lastName: "admin",
                            username: "admin@admin.com",
                            password: "admin",
                            isAdmin: true
                        }
                    }
                }
            };
        })
        .config(config)
        .run(run);

    config.$inject = ['$stateProvider', '$urlRouterProvider'];
    function config($stateProvider, $urlRouterProvider) {
        $urlRouterProvider.otherwise('/');
        $stateProvider
            .state('home', {
                url: '/',
                controller: 'HomeController',
                templateUrl: 'src/js/views/home/home.view.html',
                controllerAs: 'vm',
                params: {
                    autoActivateChild: {
                        user: 'home.myProfile',
                        admin: 'home.listUsers'
                    }
                }
            })
            .state('home.listUsers', {
                url: '^/listUsers',
                controller: 'ListUsersController',
                templateUrl: 'src/js/views/home/list-users/list-users.view.html',
                controllerAs: 'vm'
            })
            .state('home.myProfile', {
                url: '^/myProfile',
                controller: 'MyProfileController',
                templateUrl: 'src/js/views/home/my-profile/my-profile.view.html',
                controllerAs: 'vm'
            })
            .state('home.editUser', {
                url: '^/editUser',
                controller: 'EditUserController',
                templateUrl: 'src/js/views/home/edit-user/edit-user.view.html',
                controllerAs: 'vm'
            })
            .state('login', {
                url: '/login',
                controller: 'LoginController',
                templateUrl: 'src/js/views/login/login.view.html',
                controllerAs: 'vm'
            })
            .state('register', {
                url: '/register',
                controller: 'RegisterController',
                templateUrl: 'src/js/views/register/register.view.html',
                controllerAs: 'vm'
            });
    }

    run.$inject = ['$rootScope', '$location', '$cookies', '$http', '$state', 'UserService', 'providerApp'];
    function run($rootScope, $location, $cookies, $http, $state, UserService, providerApp) {

        UserService.Create(providerApp.getInitialuser());

        $rootScope.globals = $cookies.getObject('globals') || {};

        if ($rootScope.globals.currentUser) {
            $http.defaults.headers.common['Authorization'] = 'Basic ' + $rootScope.globals.currentUser.authdata;
        }

        $rootScope.$on('$locationChangeStart', function () {
            var restrictedPage = $.inArray($location.path(), ['/login', '/register']) === -1;
            var loggedIn = $rootScope.globals.currentUser;
            if (restrictedPage && !loggedIn) {
                $location.path('/login');
            }
        });

        $rootScope.$on('$stateChangeSuccess', function (event, toState) {
            var aac;
            if (aac = toState && toState.params && toState.params.autoActivateChild) {
                if ($rootScope.globals.currentUser.isAdmin) {
                    $state.go(aac.admin);
                } else {
                    $state.go(aac.user)
                }
            }
        });
    }
})();
