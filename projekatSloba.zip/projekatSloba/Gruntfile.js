module.exports = function(grunt) {
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),

        concat: {
            js: {
                src: ['src/libs/jquery-3.1.1.min.js',
                      'src/libs/bootstrap.min.js',
                      'src/libs/angular.min.js',
                      'src/libs/angular-route.min.js',
                      'src/libs/angular-cookies.min.js',
                      'src/libs/angular-ui-router.min.js',
                      'src/libs/ui-bootstrap-tpls-2.3.1.min.js',
                      'src/app.js',
                      'src/js/**/*.js'],
                dest: 'web/js/bundle.js'
            }
        },
        uglify: {
            js: {
                src: ['web/js/bundle.js'],
                dest: 'web/js/bundle.js'
            }
        }

    });

    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-uglify');

    grunt.registerTask('default', ['concat', 'uglify']);
}
